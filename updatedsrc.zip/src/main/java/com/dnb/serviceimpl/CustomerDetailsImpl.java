package com.dnb.serviceimpl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import com.dnb.model.CustomerDetails;

import com.dnb.model.CustomerPo;

public class CustomerDetailsImpl {


	// HibernateTemplate hibernateTemplate;
	public CustomerDetails getCustomerDetails(String custName, String phoneNo) throws Exception {
		// List<CustomerDetails> simpleModelList = null;
		CustomerDetails simpleModelList1 = new CustomerDetails();
		

		

		return simpleModelList1;
	}

	public String addCustomerDetails(CustomerDetails customerDetails) {
		
		return "Record Successfully Added";
	}

	public String deleteCustomerDetails(Integer id) {
		
		return "Record Deleted Successfully";
	}

	public CustomerDetails exportToExcel() {
		
		return null;
	}

}
