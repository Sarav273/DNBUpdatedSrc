package com.dnb;

import java.util.Collections;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DnbServicesApplication {

	public static void main(String[] args) {
		SpringApplication app = new SpringApplication(DnbServicesApplication.class);
		app.setDefaultProperties(Collections.singletonMap("server.servlet.context-path", "/DNB-Services"));
		app.run(args);
	}
}