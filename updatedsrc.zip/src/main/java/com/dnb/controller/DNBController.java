package com.dnb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dnb.model.CustomerDetails;



@Controller
//@RequestMapping("/customer")
//@SessionAttributes("name")
public class DNBController {
	//@Autowired
	//private CustomerDetailsImpl customerDetailsImpl;	
	
	@RequestMapping(value="/search")
	
	public  String getCustomerDetails(Model model){
		System.out.println("inside customer details");	
		CustomerDetails cusPo=new CustomerDetails();
		try {
			//cusPo= customerDetailsImpl.getCustomerDetails(name,phoneNo);
			if(cusPo !=null) {
             model.addAttribute("fname","cusPo.getName()");
             model.addAttribute("address","cusPo.getAddress()");
             model.addAttribute("creation","cusPo.getCreationdate()");
             model.addAttribute("phone","cusPo.getPhone()");
             model.addAttribute("post","cusPo.getAccom().getPost()");
             model.addAttribute("source","cusPo.getOwns().getSource()");
             
           /*  model.addAttribute("fname",cusPo.getName());
             model.addAttribute("address",cusPo.getAddress());
             model.addAttribute("creation",cusPo.getCreationdate());
             model.addAttribute("phone",cusPo.getPhone());
             model.addAttribute("post",cusPo.getAccom().getPost());
             model.addAttribute("source",cusPo.getOwns().getSource());*/
				
				/*model.addAttribute("Name",cusPo.getCustDet().getName());
			model.addAttribute("Phone",cusPo.getCustDet().getPhone());
			model.addAttribute("Address",cusPo.getCustDet().getAddress());
			model.addAttribute("creationdate",cusPo.getCustDet().getCreationdate());
		return "model";*/
		/*	model.setViewName("search");
				model.addObject("search",cusPo);
				return model;*/
				return "newResult";
          
 }} catch (Exception e){
			System.out.println("Exception"+e);
		}
		return "search";
	}
	
}
