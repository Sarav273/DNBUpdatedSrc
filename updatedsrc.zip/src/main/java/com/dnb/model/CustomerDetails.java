package com.dnb.model;

import java.io.Serializable;

public class CustomerDetails implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer id;
	private String name;
	private String address;
	private String creationdate;
	private String phone;
	
	    private CustomerloginDetails custLoginDetails;
	
	    private custinterest custInterest;
	    
	    private Accomodation accom;
	    
	    private Coners cow;
	    
	    private Owns owns; 
	    
	    private Persons persons; 
	    
	    private Visits visits;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCreationdate() {
		return creationdate;
	}

	public void setCreationdate(String creationdate) {
		this.creationdate = creationdate;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}



	@Override
	public String toString() {
		return "User [id=" + id + ", phone=" + phone + "," + ", firstName=" + name + ", Address=" + address
				+ ", Creationdate=" + creationdate + "]";
	}

	public CustomerloginDetails getCustLoginDetails() {
		return custLoginDetails;
	}

	public void setCustLoginDetails(CustomerloginDetails custLoginDetails) {
		this.custLoginDetails = custLoginDetails;
	}

	public custinterest getCustInterest() {
		return custInterest;
	}

	public void setCustInterest(custinterest custInterest) {
		this.custInterest = custInterest;
	}

	public Accomodation getAccom() {
		return accom;
	}

	public void setAccom(Accomodation accom) {
		this.accom = accom;
	}


	public Owns getOwns() {
		return owns;
	}

	public void setOwns(Owns owns) {
		this.owns = owns;
	}


	public Visits getVisits() {
		return visits;
	}

	public void setVisits(Visits visits) {
		this.visits = visits;
	}

	public Coners getCow() {
		return cow;
	}

	public void setCow(Coners cow) {
		this.cow = cow;
	}

	public Persons getPersons() {
		return persons;
	}

	public void setPersons(Persons persons) {
		this.persons = persons;
	}
}
