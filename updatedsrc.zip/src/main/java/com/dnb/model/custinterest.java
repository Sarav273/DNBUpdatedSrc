package com.dnb.model;

import java.io.Serializable;
import java.util.List;


public class custinterest implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private int id;


	private String status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
    private List<CustomerDetails> custInt;

	public List<CustomerDetails> getCustInt() {
		return custInt;
	}

	public void setCustInt(List<CustomerDetails> custInt) {
		this.custInt = custInt;
	}
 
}
