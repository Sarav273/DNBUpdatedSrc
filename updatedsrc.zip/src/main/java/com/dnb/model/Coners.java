package com.dnb.model;

import java.io.Serializable;
import java.util.List;

public class Coners implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String cowner;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

private List<CustomerDetails> custOwn;
	public List<CustomerDetails> getCustOwn() {
		return custOwn;
	}

	public void setCustOwn(List<CustomerDetails> custOwn) {
		this.custOwn = custOwn;
	}

	public String getCowner() {
		return cowner;
	}

	public void setCowner(String cowner) {
		this.cowner = cowner;
	}
}
