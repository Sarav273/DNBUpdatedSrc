package com.dnb.model;

import java.io.Serializable;
import java.util.List;


public class custact implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String logindate;
	private int logindetails;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLogindate() {
		return logindate;
	}

	public void setLogindate(String logindate) {
		this.logindate = logindate;
	}

	public int getLogindetails() {
		return logindetails;
	}

	public void setLogindetails(int logindetails) {
		this.logindetails = logindetails;
	}

	
	private List<custinterest> custIn;

	public List<custinterest> getCustIn() {
		return custIn;
	}

	public void setCustIn(List<custinterest> custIn) {
		this.custIn = custIn;
	}
}
