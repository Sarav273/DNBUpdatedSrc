package com.dnb.model;

import java.io.Serializable;
import java.util.List;


public class Owns implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String source;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

private List<CustomerDetails> custOwns;
	public List<CustomerDetails> getCustOwns() {
		return custOwns;
	}

	public void setCustOwns(List<CustomerDetails> custOwns) {
		this.custOwns = custOwns;
	}

}
