package com.dnb.model;

import java.io.Serializable;
import java.util.*;

public class Persons implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String agent;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	    private List<CustomerDetails> custPerson;

	public List<CustomerDetails> getCustPerson() {
		return custPerson;
	}

	public void setCustPerson(List<CustomerDetails> custPerson) {
		this.custPerson = custPerson;
	}

	public String getAgent() {
		return agent;
	}

	public void setAgent(String agent) {
		this.agent = agent;
	}
}
