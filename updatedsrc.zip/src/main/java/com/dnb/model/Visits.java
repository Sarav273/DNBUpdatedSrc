package com.dnb.model;

import java.io.Serializable;
import java.util.List;


public class Visits implements Serializable {
	/**
		 * 
		 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String start;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	private List<CustomerDetails> custVisits;

	public List<CustomerDetails> getCustVisits() {
		return custVisits;
	}

	public void setCustVisits(List<CustomerDetails> custVisits) {
		this.custVisits = custVisits;
	}

	public String getStart() {
		return start;
	}

	public void setStart(String start) {
		this.start = start;
	}
}
