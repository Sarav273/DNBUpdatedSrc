package com.dnb.model;

import java.io.Serializable;
import java.util.List;

public class Accomodation implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int id;
	private String post;
   public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

private List<CustomerDetails> custAcco;
	
	public List<CustomerDetails> getCustAcco() {
		return custAcco;
	}

	public void setCustAcco(List<CustomerDetails> custAcco) {
		this.custAcco = custAcco;
	}

	public String getPost() {
		return post;
	}

	public void setPost(String post) {
		this.post = post;
	}

}
